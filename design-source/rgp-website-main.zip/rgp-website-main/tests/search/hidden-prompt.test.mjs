/**
 * The search:connect secret prompt (scripts/lib/hidden-prompt.mjs): pastes arriving in chunks, CRLF (also split
 * across chunks), bracketed paste, no echo, and a rejected value whose leftover input is drained instead of
 * reaching the shell. Run: npm run test:search
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { PassThrough } from 'node:stream';
import { createLineBuffer, HiddenInput, askValid, Cancelled, checkClientId, checkClientSecret, checkBingKey } from '../../scripts/lib/hidden-prompt.mjs';

const ID = '123456789012-abcdefghijklmnopqrstuvwxyz012345.apps.googleusercontent.com';
const SECRET = 'GOCSPX-AbCdEfGhIjKlMnOpQrStUvWxYz12';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function io(opts = {}) {
  const input = new PassThrough();
  const output = new PassThrough();
  let shown = '';
  output.on('data', (d) => { shown += d; });
  const h = new HiddenInput({ input, output, quietMs: 40, maxDrainMs: 1000, ...opts }).start();
  return { h, input, shown: () => shown };
}

test('line buffer: chunks, CRLF split across chunks, bracketed paste, backspace', () => {
  const b = createLineBuffer();
  b.push('GOCSPX-abc'); b.push('def'); b.push('\r');
  assert.equal(b.shift(), 'GOCSPX-abcdef');
  b.push('\n');                                   // the \n of the \r\n arrives in the next chunk
  assert.equal(b.shift(), undefined, 'a split CRLF is one Enter, not an extra empty answer');
  b.push('\x1b[200~pasted\x1b[201~\r\n');
  assert.equal(b.shift(), 'pasted');
  b.push('abx\x7fc\n');
  assert.equal(b.shift(), 'abc');
  b.push('\x1b[Aup\n');                            // arrow key ignored
  assert.equal(b.shift(), 'up');
  assert.equal(b.push('\x03').cancel, true);
});

test('a paste in several chunks with a trailing newline is read whole and never echoed', async () => {
  const { h, input, shown } = io();
  const answer = h.ask('Google OAuth client ID: ');
  for (const part of [ID.slice(0, 10), ID.slice(10, 40), ID.slice(40)]) { input.write(part); await sleep(5); }
  input.write('\r\n');
  assert.equal(await answer, ID);
  const secret = h.ask('Google OAuth client secret: ');
  input.write(`${SECRET}\n`);
  assert.equal(await secret, SECRET);
  h.stop();
  assert.equal(shown(), 'Google OAuth client ID: \nGoogle OAuth client secret: \n');
  assert.ok(!shown().includes('GOCSPX') && !shown().includes('googleusercontent'));
});

test('CRLF paste: the \\n does not answer the next question', async () => {
  const { h, input } = io();
  const first = h.ask('one: ');
  input.write(`${ID}\r`);
  assert.equal(await first, ID);
  const second = h.ask('two: ');
  input.write('\n');                // late half of the CRLF
  await sleep(10);
  input.write(`${SECRET}\r\n`);
  assert.equal(await second, SECRET);
  h.stop();
});

test('a too-short value is rejected, its leftover input is drained, and the retry gets only the new paste', async () => {
  const { h, input, shown } = io();
  const result = askValid(h, 'Google OAuth client secret: ', checkClientSecret);
  input.write('GOCSPX-short\n');
  input.write('rm -rf ~ # leftover');            // what used to spill into the shell
  await sleep(15);
  input.write(' more leftover\n');
  await sleep(150);                               // drain finishes after 40 ms of quiet
  input.write(`${SECRET}\n`);
  assert.equal(await result, SECRET);
  assert.equal(h.buf.pending, 0, 'nothing left buffered');
  h.stop();
  assert.match(shown(), /✗ that is not a Google OAuth client secret .*got 12 characters/);
  assert.ok(!/short|leftover|rm -rf/.test(shown()), 'rejected input is never shown');
});

test('three bad values → error; Ctrl-C → Cancelled', async () => {
  const a = io();
  const r = askValid(a.h, 'id: ', checkClientId, { tries: 2 });
  a.input.write('nope\n'); await sleep(120); a.input.write('still nope\n');
  await assert.rejects(r, /no valid value after 2 tries/);
  a.h.stop();
  const b = io();
  const c = b.h.ask('id: ');
  b.input.write('abc\x03');
  await assert.rejects(c, Cancelled);
  b.h.stop();
});

test('optional answer: Enter skips', async () => {
  const { h, input } = io();
  const r = askValid(h, 'Bing key (Enter to skip): ', checkBingKey, { optional: true });
  input.write('\r');
  assert.equal(await r, '');
  h.stop();
});

test('validators', () => {
  assert.equal(checkClientId(ID), null);
  assert.ok(checkClientId('abc.apps.googleusercontent.com'));
  assert.equal(checkClientSecret(SECRET), null);
  assert.ok(checkClientSecret('GOCSPX-'));
  assert.ok(checkClientSecret(`x${SECRET}`));
  assert.equal(checkBingKey('0123456789abcdef0123456789abcdef'), null);
  assert.ok(checkBingKey('0123 4567'));
  assert.ok(!checkClientSecret('GOCSPX-oops').includes('oops'), 'messages never repeat the value');
});
